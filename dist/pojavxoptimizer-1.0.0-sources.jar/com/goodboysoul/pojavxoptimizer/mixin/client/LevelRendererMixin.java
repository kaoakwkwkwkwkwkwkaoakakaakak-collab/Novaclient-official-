package com.goodboysoul.pojavxoptimizer.mixin.client;

import com.goodboysoul.pojavxoptimizer.PojavXOptimizer;
import com.goodboysoul.pojavxoptimizer.core.ViewState;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Records what the renderer is about to draw, and feeds the view direction to chunk prioritisation.
 *
 * <p>Injected at the head of {@code setupRender}, which is where vanilla finalises the camera and
 * frustum for the frame. Everything here is read-only observation: no field is modified and no
 * vanilla decision is overridden, so a mod that replaces the renderer simply never triggers this
 * hook, and a mod that adds its own setup logic coexists with it.
 *
 * <p>The view direction captured here is what lets {@code ChunkPrioritizer} build what the player is
 * looking at first. Without it the prioritiser would fall back to plain distance ordering, which is
 * exactly the "chunks fill in as a disc around me" behaviour this mod is trying to remove.
 */
@Mixin(class_761.class)
public abstract class LevelRendererMixin {

    @Inject(method = "setupRender", at = @At("HEAD"))
    private void pjo$captureView(class_4184 camera, class_4604 frustum,
                                 boolean captureFrustum, boolean isSpectator, CallbackInfo ci) {
        if (!PojavXOptimizer.isReady() || camera == null) {
            return;
        }
        try {
            PojavXOptimizer mod = PojavXOptimizer.get();
            double camX = camera.method_19326().field_1352;
            double camY = camera.method_19326().field_1351;
            double camZ = camera.method_19326().field_1350;
            float lookX = camera.method_19335().x();
            float lookY = camera.method_19335().y();
            float lookZ = camera.method_19335().z();

            ViewState.update(camX, camY, camZ, lookX, lookY, lookZ);
            mod.chunkPrioritizer().setView(camX, camY, camZ, lookX, lookY, lookZ);
        } catch (RuntimeException captureFailed) {
            // Observation only: a failure here must not affect rendering.
            if (!pjo$captureErrorLogged) {
                pjo$captureErrorLogged = true;
                com.goodboysoul.pojavxoptimizer.core.PJO.warn(
                        "Could not capture the view direction; chunk prioritisation will use "
                        + "plain distance ordering.", captureFailed);
            }
        }
    }

    @Unique
    private boolean pjo$captureErrorLogged;
}
