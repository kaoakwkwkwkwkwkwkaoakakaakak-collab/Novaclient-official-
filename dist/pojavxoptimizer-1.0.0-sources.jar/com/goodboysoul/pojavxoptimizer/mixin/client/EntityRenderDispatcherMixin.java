package com.goodboysoul.pojavxoptimizer.mixin.client;

import com.goodboysoul.pojavxoptimizer.PojavXOptimizer;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds distance and projected-size tests to the existing entity visibility decision.
 *
 * <p>Vanilla's {@code shouldRender} already handles frustum culling correctly, so this does not
 * replace it — it only adds a refusal on top. When PojavXOptimizer is not ready, not configured for
 * entity culling, or the entity is the one the player is riding, the original result stands.
 *
 * <p>The rider exception is not cosmetic. Culling the entity you are sitting on removes your own
 * mount from the world, which reads as a serious bug rather than as an optimisation.
 */
@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void pjo$extraCullChecks(class_1297 entity, class_4604 frustum,
                                     double cameraX, double cameraY, double cameraZ,
                                     CallbackInfoReturnable<Boolean> cir) {
        if (!PojavXOptimizer.isReady() || entity == null) {
            return;
        }
        PojavXOptimizer mod = PojavXOptimizer.get();
        if (!mod.config().entityCulling()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.method_1560() == entity) {
            return;
        }

        double distanceSquared = pjo$distanceSquared(entity, cameraX, cameraY, cameraZ);
        double width = pjo$entityWidth(entity);

        float fov = client.field_1690 != null && client.field_1690.method_41808() != null
                ? client.field_1690.method_41808().method_41753().floatValue()
                : 70.0f;
        int viewportHeight = client.method_22683() != null
                ? client.method_22683().method_4507()
                : 1080;

        if (mod.entityCullPolicy().shouldCull(distanceSquared, width, fov, viewportHeight)) {
            cir.setReturnValue(false);
        }
    }

    @Unique
    private double pjo$distanceSquared(class_1297 entity, double cameraX, double cameraY, double cameraZ) {
        double dx = entity.method_23317() - cameraX;
        double dy = entity.method_23318() - cameraY;
        double dz = entity.method_23321() - cameraZ;
        return dx * dx + dy * dy + dz * dz;
    }

    @Unique
    private double pjo$entityWidth(class_1297 entity) {
        try {
            class_238 box = entity.method_5829();
            return box == null ? 0.6 : box.method_17939();
        } catch (RuntimeException boxUnavailable) {
            // Some entity types override bounding-box access and can throw before they are fully
            // initialised. A default width keeps culling conservative instead of crashing.
            return 0.6;
        }
    }
}
